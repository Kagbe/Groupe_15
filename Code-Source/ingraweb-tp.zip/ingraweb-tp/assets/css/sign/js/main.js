/*
 Transformer un element en un tableau:      [].slice.call()

 ClassList : pour afficher toutes les classe
 Toggle : d'ajouter s'il en a pas encore ou de retirer une classe s'elle existe 
 Add : pour ajouter une classe ou un element
 Remove: pour retirer une classe ou element


 EVENT = recuperer un evenement clické

 Ensuite stocker cet evenement dans la constante /ELEMENT/
 
 Et recuperer l'attribut /data-mobile/ grace au js: dataset.mobile et stocker dans la const className


 */

const iconToggleMobileNav = document.getElementById("toggleMobileNav")

const iconToggleCart = document.getElementById("openCart")
const iconToggleCartO = document.getElementById("openCartO")




const closeMobileNavs = [].slice.call(document.getElementsByClassName("mobile-close"))



const toggleNav = (event) => {
    const element = event.target
    const className = element.dataset.mobile

    const mobileNav = document.getElementsByClassName(className)[0] // recuperer le 1er element du tableau de la classe /mobile/
    if(!mobileNav.classList.contains("none")) // si la classe n'est pas encore ajouter
    {
        mobileNav.classList.toggle("close") // ajouter la classe close pour que le fichier keyFrames.css fonction
        window.setTimeout(() =>{
            mobileNav.classList.toggle("none")
            mobileNav.classList.toggle("close") // enlever la classe close pour mettre fin au fichier keyFrames.css
        }, 1000) // RETARDER DE 1s AVANT DE L'AJOUTER


        document.body.style.overflow = ""
    }else{ 
        // sinon ajouter la classe /none/
        mobileNav.classList.toggle("none")

        document.body.style.overflow = "hidden" // bloquer le scrol de la page
    }
}




iconToggleMobileNav.addEventListener("click", toggleNav)
iconToggleCart.addEventListener("click", toggleNav)
iconToggleCartO.addEventListener("click", toggleNav)

closeMobileNavs.forEach(item => {
    item.addEventListener("click", toggleNav)
});




/*----------------------------- MON COMPTE ------------------------ */
document.querySelector(".slider-close").addEventListener("click", () => {
    document.querySelector("#slider-account").style.display="none"
})


document.querySelector("#openAcount").addEventListener("click", () => {
    document.querySelector("#slider-account").classList.toggle("none")
})