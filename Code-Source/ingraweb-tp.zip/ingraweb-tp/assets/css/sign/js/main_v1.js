/*
 Transformer un element en un tableau:      [].slice.call()

 ClassList : pour afficher toutes les classe
 Toggle : d'ajouter s'il en a pas encore ou de retirer une classe s'elle existe 
 Add : pour ajouter une classe ou un element
 Remove: pour retirer une classe ou element





 */

const iconToggleMobileNav = document.getElementById("toggleMobileNav")
const closeMobileNavs = [].slice.call(document.getElementsByClassName("mobile-close"))

const toggleNav = () => {
    const mobileNav = document.getElementsByClassName("mobile")[0] // recuperer le 1er element du tableau de la classe /mobile/
    if(!mobileNav.classList.contains("none")) // si la classe n'est pas encore ajouter
    {
        mobileNav.classList.toggle("close") // ajouter la classe close pour que le fichier keyFrames.css fonction
        window.setTimeout(() =>{
            mobileNav.classList.toggle("none")
            mobileNav.classList.toggle("close") // enlever la classe close pour mettre fin au fichier keyFrames.css
        }, 2000) // RETARDER DE 2s AVANT DE L'AJOUTER


        document.body.style.overflow = ""
    }else{ 
        // sinon ajouter la classe /none/
        mobileNav.classList.toggle("none")

        document.body.style.overflow = "hidden" // bloquer le scrol de la page
    }
}




iconToggleMobileNav.addEventListener("click", toggleNav)

closeMobileNavs.forEach(item => {
    item.addEventListener("click", toggleNav)
});