
'use strict';
// la fonction elementtoogle

const elemToggleFunc= function(elem) {
    elem.classList.toggle("active");
}

// navbar toggle

const navbar = document.querySelector("[data-navbar]");
const overlay = document.querySelector("[data-overlay]");
const navCloseBtn = document.querySelector("[data-nav-close-btn]");
const navOpenBtn = document.querySelector("[data-nav-open-btn]");
const navbarlinks = document.querySelectorAll("[data-nav-link]");


const navElemArr=[overlay, navCloseBtn, navOpenBtn];
 
//navbar se ferme quand on fait un clique sur le lien de navbar

for(let i=0; i < navbarlinks.length; i++) {
    navElemArr.push(navbarlinks[i]);
}

//ajouter un evenement a tous les elements de toggling de navbar

for(let i=0; i < navElemArr.length; i++){
    navElemArr[i].addEventListener("click", function (){
        elemToggleFunc(navbar);
        elemToggleFunc(overlay);

    });
}


const header=document.querySelector("[data-header]");

window.addEventListener("scroll", function() {
    window.scrollY >= 200 ? header.classList.add("active"):header.classList.remove("active");
});






/* popup */

const popup = document.querySelector("#popup")
popup.style.display="none"