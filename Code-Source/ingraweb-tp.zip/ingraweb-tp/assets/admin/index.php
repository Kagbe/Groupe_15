<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/image/icon.jpg" type="image/x-icon" class="border-radius">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="../css/sign/css/main.css">
    <title>Location de Maison</title>
</head>
<body>
    <?php 
        if (!empty($_SESSION['email'])) {
            $me = "<a href='assets/php/deconnexion/deconnexion.php' onmouseover='compte()' id='compte' name='deconnexion'>Deconnexion<img src='image/user5.png' class='fermer' onclick='fermer()'></a>";
        }else
            
    ?>  
    <header id="admin">
        <ul>
            <li><a href="../../">Home</a></li>
            <?php include "assets/php/requetes/maSession.php"; echo @$link;?>
            <?php echo @$me;?>
        </ul>
    </header>
    <div class="container-admin">
        <div class="container-top-admin">
            <div class="block centrer">
                <h1>BIENVENUE</h1>
                <p>dans votre espace</p>
                <input type="button" value="VOIR">
            </div>
        </div>
        <div class="container-bottom-admin">
        <div class="items-admin container-items-admin flex">
        <?php
            include "../php/requetes/db-connexion.php";
                @$sql = "SELECT * FROM chambre";
                @$exe = mysqli_query($con,$sql);
                while(@$affiche = mysqli_fetch_array($exe)){
            ?>
            
                <div class="items block centrer">
                    <div class="item">
                        <img src="<?php echo "assets/php/requetes/basedeDonnees/".$affiche['photo']?>" id="id_chambre">
                        <div class="prix"><?php echo $affiche['prix_chambre'];?> FCFA</div>
                        <p>
                            <?php echo $affiche['category'].' N° '.$affiche['id_chambre'].' à '.$affiche['lieu_chambre'];?>
                        </p>
                    </div>
                </div>
            
            <?php }?>
            </div>
        </div>
            <div class="numero flex">
                &lt;
                <a href="#">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                &gt;
            </div>
        </div>
    </div>
    <footer class="py-50">
        <div class="container">
            <div class="footer-content flex jcsb wrap pb-30">
                <div class="footer-list">
                    <h2>Contact Infos</h2>
                    <div class="footer-item">
                        <h4>Adresse : </h4>
                        <p>123 Street Name, City, Egland</p>
                    </div>
                    <div class="footer-item">
                        <h4>Phone : </h4>
                        <p>(123) 456-8960</p>
                    </div>
                    <div class="footer-item">
                        <h4>Email : </h4>
                        <p>mail@example.com</p>
                    </div>
                    <div class="footer-item">
                        <h4>Working Days/Hours : </h4>
                        <p>Mon - Sun / 9:00 AM - 8:00 PM</p>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Customers Service</h2>
                    <ul>
                        <li class="customer-service-item"><a href="#">Help & FAQs</a></li>
                        <li class="customer-service-item"><a href="#">Order Tracking</a></li>
                        <li class="customer-service-item"><a href="#">Shipping & Delivery</a></li>
                        <li class="customer-service-item"><a href="#">Orders History</a></li>
                        <li class="customer-service-item"><a href="#">Advanced Search</a></li>
                        <li class="customer-service-item"><a href="#">My Account</a></li>
                        <li class="customer-service-item"><a href="#">Careers</a></li>
                        <li class="customer-service-item"><a href="#">About Us</a></li>
                        <li class="customer-service-item"><a href="#">Corporate Sales</a></li>
                        <li class="customer-service-item"><a href="#">Privacy</a></li>
                    </ul>
                </div>
                <div class="footer-list">
                    <h2>Popular Tags</h2>
                    <div class="footer-tags flex wrap gap-5">
                        <div class="tags">bags</div>
                        <div class="tags">black</div>
                        <div class="tags">blue</div>
                        <div class="tags">clothes</div>
                        <div class="tags">Fashion</div>
                        <div class="tags">Hub</div>
                        <div class="tags">Shirt</div>
                        <div class="tags">Shoes</div>
                        <div class="tags">Skirt</div>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Subscribe Newsletter</h2>
                    <div class="footer-subscribe">
                        <p>
                            Get all the latest information on events, sales and offers. Sign up for newsletter:
                        </p>
                        <div class="footer-input">
                            <input type="email" name="email" id="email" placeholder="Email Address">
                        </div>
                        <button class="btn">Subscribe</button>
                    </div>
                </div>
            </div>
            <div class="footer-bottom flex jcsb py-30 wrap gap-10">
                <div class="footer-bottom-left">
                    © City Univ. 2024. All Rights Reserved
                </div>
                <div class="footer-bottom-right flex gap-10">
                    <img src="assets/images/card/mastercard.svg" alt="">
                    <img src="assets/images/card/cb.svg" alt="">
                    <img src="assets/images/card/visa.svg" alt="">
                    <img src="assets/images/card/oney.svg" alt="">
                </div>
            </div>
        </div>
    </footer>
</body>
</html>

    <script type="text/javascript" language="javascript">

        function compte() {
            //document.querySelector('#mon_compte').style.visibility = "visible"
        }
        function fermer() {
            var z = document.querySelector('.fermer')
            z.style.visibility = "visible"
            document.querySelector('#mon_compte').style.visibility = "hidden"
        }
    </script>
    <style type="text/css">
.fermer{
    font-style: normal;
    position: absolute;
    color: black;
    height: 30px;
    width: 30px;
    margin-left: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-image: url('image/user5.png');
    background-position: center;
    font-size: 10px;
    border-radius: 100%;
}
div.items{
        width: 70%;
    }
    div.item{
        margin: 2px;
    }
    #id_maison{
        width: 150px;
        height: 150px;
    }
    </style>