<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un ordinateur</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <header>
        <ul>
            <li><a href="index.php">City-Univ</a></li>
        </ul>
        <ul>
            <li><a href="#">Contact</a></li>
            <?php include "php/requetes/maSession.php"; echo @$link;?>
        </ul>
        <ul>
            <?php echo @$me;?>
        </ul>
    </header>
    <div class="container">
        
        <div class="admin">
            <h1>Supprimer un ordinateur</h1>
            <form action="#" method="post" enctype="multipart/form-data">
                <div class="searche">
                    <select name="btnsearch" id="">
                        
                    <?php
                        include "php/requetes/connexion.php";
                        $sql = "SELECT marque FROM all_ordinateur";
                        $exe = mysqli_query($con,$sql);
                        while($affiche = mysqli_fetch_array($exe)){
                    ?>
                    <option value="<?php echo $affiche['marque'];?>"><a href="#"><?php echo $affiche['marque'];?></a></option>
                    <?php }?>
                    </select>
                    <input type="submit" value="Recherche">
                </div>
                <?php echo @$_GET['erreur'];?>
            <?php include "php/requetes/supprimer.php";?>
            </form>
        </div>
        <div class="container-bottom">
        <div class="items container-items flex">
        <?php
            include "php/requetes/connexion.php";
                $sql = "SELECT * FROM all_ordinateur";
                $exe = mysqli_query($con,$sql);
                while($affiche = mysqli_fetch_array($exe)){
            ?>
            
                <div class="items block centrer">
                    <img src="<?php echo "php/requetes/basedeDonnees/".$affiche['photo']?>">
                    <div class="prix"><?php echo $affiche['prix'];?> $</div>
                    <p>
                        <?php echo $affiche['marque'].' '.$affiche['disque']."Go/".$affiche['processeur']."Hz  ".$affiche['ecran']."''  ";?>
                    </p>
                </div>
            
            <?php }?>
            </div>
        </div>
    </div>
    <footer>
        <nav>
            <ul>
                <li><a href="#">E-Commerce</a></li>
                <li><a href="#">Bureau</a></li>
            </ul>
            <ul>
                <li><a href="#">Accueil</a></li>
                <li><a href="#">Presentation</a></li>
                <li><a href="#">A propos</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#">Panier</a></li>
            </ul>
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Whatsapp</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Linkedin</a></li>
        </nav>
        </ul>
        <div>Copyright @ Kainbaouin Jonas 20A422FS</div>
    </footer>
</body>

<style>
    
article{
    width: 100%;
    height: 200px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
}
article img{
    width: 100%;
    height: 100%;
}
.searche{
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: auto;
    margin-bottom: 20px;
    background-color: white;
}
.searche select{
    width: 50%;
    height: 29px;
    outline: none;
    border: 1px solid #ccc;
}
.searche input{
    height: 31px;
    width: 100px;
    border: 1px solid #ccc;
    border-left: none;
}
.admin{
    background-color: white;
    height: 100vh;
    padding-top: 100px;
    padding-left: 10px;
    padding-right: 10px;
}
.admin .admin-container{
    background-color: white;
    width: 100%;
    height: 500px;
    box-shadow: 1px 1px 10px #ccc;
}
.admin-container section{
    flex: 1;
    margin: 10px;
    padding: 10px;
    text-align: center;
    box-shadow: 1px 1px 10px #ccc;
}
.admin-container section input{
    margin-bottom: 10px;
    width: 100%;
    height: 30px;
    font-size: 20px;
    font-family: Arial, Helvetica, sans-serif;
}
.admin-container section input:hover{
    border-color: aqua;
}
.admin-container section input[type="file"]{
    text-align: left;
    width: 100%;
}
.admin-container section textarea{
    width: 100%;
    height: 200px;
}
form{
    text-align: center;
}
</style>
</html>
