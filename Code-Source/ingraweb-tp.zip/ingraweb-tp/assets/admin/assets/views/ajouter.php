<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../../../css/sign/css/main.css">
</head>
<body>
<header id="admin">
        <ul>
            <li><a href="../../">Home</a></li>
            <?php include "../php/requetes/maSession.php"; echo @$link;?>
            <?php echo @$me;?>
        </ul>
    </header>
    <div class="container-admin">
        <div class="admin">
            <h1>Ajouter une Maison</h1>
            <?php echo @$_GET['erreur'];?>
            <form action="../php/requetes/ajouter.php" method="post" enctype="multipart/form-data">
                <div class="flex admin-container">
                    
                    <section class="flex-1">
                        <input type="text" placeholder="Titre" name="titre" required>
                        <input type="text" placeholder="Category" name="category" required>
                        <input type="number" placeholder="Prix" name="prix" required>
                        <input type="text" placeholder="Lieu" name="lieu" required>
                        <input type="number" placeholder="Surface" name="surface" required>
                    </section>
                    <section class="flex-1">
                        <input type="file" name="image" required>
                        <textarea name="descriptionO" id="">description</textarea>
                        <input type="submit" name="butn">
                    </section>
                </div>
            </form>
        </div>
        <div class="container-bottom">
        <div class="items container-items flex">
        <?php
                
                @$sql = "SELECT * FROM chambre";
                @$exe = mysqli_query($con,$sql);
                while(@$affiche = mysqli_fetch_array($exe)){
            ?>
            
                <div class="items block centrer">
                    <div class="item">
                        <img src="<?php echo "../php/requetes/basedeDonnees/".$affiche['photo']?>" id="id_maison">
                        <div class="prix"><?php echo $affiche['prix_chambre'];?> $</div>
                        <p>
                            <?php echo $affiche['titre'].' '.$affiche['category']." / N° ".$affiche['id_chambre']."  ".$affiche['surface']."'m²'  ";?>
                        </p>
                        <button>Reserver</button>
                    </div>
                </div>
            
            <?php }?>
            </div>
        </div>
    </div>
    <footer class="py-50">
        <div class="container">
            <div class="footer-content flex jcsb wrap pb-30">
                <div class="footer-list">
                    <h2>Contact Infos</h2>
                    <div class="footer-item">
                        <h4>Adresse : </h4>
                        <p>123 Street Name, City, Egland</p>
                    </div>
                    <div class="footer-item">
                        <h4>Phone : </h4>
                        <p>(123) 456-8960</p>
                    </div>
                    <div class="footer-item">
                        <h4>Email : </h4>
                        <p>mail@example.com</p>
                    </div>
                    <div class="footer-item">
                        <h4>Working Days/Hours : </h4>
                        <p>Mon - Sun / 9:00 AM - 8:00 PM</p>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Customers Service</h2>
                    <ul>
                        <li class="customer-service-item"><a href="#">Help & FAQs</a></li>
                        <li class="customer-service-item"><a href="#">Order Tracking</a></li>
                        <li class="customer-service-item"><a href="#">Shipping & Delivery</a></li>
                        <li class="customer-service-item"><a href="#">Orders History</a></li>
                        <li class="customer-service-item"><a href="#">Advanced Search</a></li>
                        <li class="customer-service-item"><a href="#">My Account</a></li>
                        <li class="customer-service-item"><a href="#">Careers</a></li>
                        <li class="customer-service-item"><a href="#">About Us</a></li>
                        <li class="customer-service-item"><a href="#">Corporate Sales</a></li>
                        <li class="customer-service-item"><a href="#">Privacy</a></li>
                    </ul>
                </div>
                <div class="footer-list">
                    <h2>Popular Tags</h2>
                    <div class="footer-tags flex wrap gap-5">
                        <div class="tags">bags</div>
                        <div class="tags">black</div>
                        <div class="tags">blue</div>
                        <div class="tags">clothes</div>
                        <div class="tags">Fashion</div>
                        <div class="tags">Hub</div>
                        <div class="tags">Shirt</div>
                        <div class="tags">Shoes</div>
                        <div class="tags">Skirt</div>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Subscribe Newsletter</h2>
                    <div class="footer-subscribe">
                        <p>
                            Get all the latest information on events, sales and offers. Sign up for newsletter:
                        </p>
                        <div class="footer-input">
                            <input type="email" name="email" id="email" placeholder="Email Address">
                        </div>
                        <button class="btn">Subscribe</button>
                    </div>
                </div>
            </div>
            <div class="footer-bottom flex jcsb py-30 wrap gap-10">
                <div class="footer-bottom-left">
                    © City Univ. 2024. All Rights Reserved
                </div>
                <div class="footer-bottom-right flex gap-10">
                    <img src="assets/images/card/mastercard.svg" alt="">
                    <img src="assets/images/card/cb.svg" alt="">
                    <img src="assets/images/card/visa.svg" alt="">
                    <img src="assets/images/card/oney.svg" alt="">
                </div>
            </div>
        </div>
    </footer>
</body>

<style>
    div.items{
        width: 70%;
    }
    div.item{
        margin: 2px;
    }
    #id_maison{
        width: 150px;
        height: 150px;
    }
    .container-admin{
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .admin{
        width: 100vw;
    }
    .admin .admin-container{
        background-color: white;
        
        width: 100%;
        height: auto;
    }
    .admin-container section{
        flex: 1;
        padding: 10px;
        text-align: center;
        box-shadow: 1px 1px 10px #ccc;
    }
    .admin-container section input{
        margin-bottom: 10px;
        width: 100%;
        height: 30px;
        font-size: 20px;
        font-family: Arial, Helvetica, sans-serif;
    }
    .admin-container section input:hover{
        border-color: aqua;
    }
    .admin-container section input[type="file"]{
        text-align: left;
        width: 100%;
    }
    .admin-container section textarea{
        width: 100%;
        height: 200px;
    }
</style>
</html>
