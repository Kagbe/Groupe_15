<?php
    session_start();
    if (isset($_POST['btn_connexion'])) {
    	$nom = $_POST['nom'];
    	$pwd = $_POST['pwd'];
    	if (!empty($nom)) {
	    	include_once("connexion.php");
		    $exe = $bd -> prepare('SELECT * FROM users WHERE nom= ? AND pass= ?');
		    $exe -> execute(array($nom, $pwd));
		    if ($exe -> rowCount() > 0) {
		    	$_SESSION['nom'] = $nom;
		    	$_SESSION['pwd'] = $pwd;
		    	$_SESSION['id'] = $exe->fetch()['idu'];
		    	header("location: ../../index.php");
		    }else
		    	header("location: http://localhost/projet_ecommerce/connexion.php?erreur=Votre mot de passe ou nom est incorrect ...");
		}else
    		header("location: http://localhost/projet_ecommerce/connexion.php?erreur=Remplir tous les champs ...");
    }
?>