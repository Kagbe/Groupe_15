
<?php
/*
	connexion avec la methode simple
*/
    $con = mysqli_connect('127.0.0.1', 'root', '','db_cite_univ') or die ("Echec de connexion...");


/*
	connexion avec la methode PDO
*/
    $bd = new PDO('mysql:host=localhost;dbname=db_cite_univ;charset=utf8;','root','') or die ("Echec de connexion...");
?>


<?php
        if (isset($_POST['butn'])) {
            $titre = $_POST['titre'];
            $category = $_POST['category'];
            $prix = $_POST['prix'];
            $lieu = $_POST['lieu'];
            $surface = $_POST['surface'];
            $desk = $_POST['descriptionO'];

            // image
            $img = $_FILES['image']['name'];
            $taille = $_FILES['image']['size'];
            $error = $_FILES['image']['error'];
            $source = $_FILES['image']['tmp_name'];
            $extenTab = ['jpg','jpeg','png','bmp','gif','tif'];
            @$extF=strtolower(end(explode('.',$img)));

        if ($error==0 && $taille < 100001100) {
            if (in_array($extF,$extenTab)) {
                $photo = uniqid("",true);
                $photo = $photo.'.'.$extF;
                if (move_uploaded_file($source, "basedeDonnees/".$photo)) {
                    
                    $sql = "INSERT INTO chambre (titre, category,prix_chambre,lieu_chambre,surface,description,photo) VALUES ('$titre', '$category','$prix','$lieu','$surface','$desk', '$photo')";
                    
                    //include "../../php/requetes/db-connexion.php";
                    
                    $exe = mysqli_query($con,$sql);
                    
                    if ($exe){
                        header ("Location: ../../views/ajouter.php?erreur=Ajouter avec success..."); 
                    }
                }else
                    header("location: ../views/ajouter.php?erreur=Utilisateur non enregistre...");
            }else
                header("location: ../views/ajouter.php?erreur=Extension du fichier non autorisee...");
        }else
            header("location: ../views/ajouter.php?erreur=erreur sur le fichier ou taille trop importante...");
        mysqli_close($con);

        }
    ?>   