<?php
        if (isset($_POST['btnsearch'])) {
            $elmt = $_POST['btnsearch'];
            include_once('connexion.php');
            $sql = "SELECT * FROM all_ordinateur WHERE marque='$elmt' OR modele='$elmt' OR descriptionOrd='$elmt'";
            $exe = mysqli_query($con,$sql);
            while($affiche = mysqli_fetch_array($exe)){
    ?>   
                <div class="flex admin-container">
                    <section class="flex-1">
                        <input type="text" placeholder="Marque" name="mark" value="<?php echo $affiche['marque'];?>">
                        <input type="text" placeholder="Modele" name="modele" value="<?php echo $affiche['modele'];?>">
                        <input type="number" placeholder="Prix" name="prix" value="<?php echo $affiche['prix'];?>">
                        <input type="text" placeholder="Ecran en ''" name="ecran" value="<?php echo $affiche['ecran'];?>">
                        <input type="number" placeholder="Disque" name="disk" value="<?php echo $affiche['disque'];?>">
                        <input type="number" placeholder="Processeur" name="proces" value="<?php echo $affiche['processeur'];?>">
                        <input type="submit" name="butn" value="Mettre a jour">
                    </section>
                    <section class="flex-1">
                        <article><img src="<?php echo "php/requetes/basedeDonnees/".$affiche['photo'];?>"></article>
                        <textarea name="descriptionO" id=""><?php echo $affiche['descriptionOrd'];?></textarea>
                    </section>
                </div>

    <?php }}?>
    <?php 
        if (isset($_POST['butn']) && !empty($_POST['btnsearch'])) {
            $mark = $_POST['mark'];
            $model = $_POST['modele'];
            $prix = $_POST['prix'];
            $ecran = $_POST['ecran'];
            $disk = $_POST['disk'];
            $pro = $_POST['proces'];
            $desk = $_POST['descriptionO'];
            $sql = "UPDATE all_ordinateur SET marque='$mark', modele='$model', descriptionOrd='$desk', prix='$prix', ecran='$ecran', disque='$disk',processeur='$pro' WHERE marque='$elmt' OR modele='$elmt' OR descriptionOrd='$elmt'";
            $exe = mysqli_query($con,$sql);
            header("location: http://localhost/projet_ecommerce/update.php?erreur=Modifier avec success...");
        }
    ?>