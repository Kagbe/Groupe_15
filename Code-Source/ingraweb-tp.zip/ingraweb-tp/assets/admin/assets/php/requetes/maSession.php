<?php
/*
	connexion avec la methode simple
*/
    $con = mysqli_connect('127.0.0.1', 'root', '','db_cite_univ') or die ("Echec de connexion...");


/*
	connexion avec la methode PDO
*/
    $bd = new PDO('mysql:host=localhost;dbname=db_cite_univ;charset=utf8;','root','') or die ("Echec de connexion...");
?>

<?php


    if (!empty($_SESSION['email'])) {
        $i = $_SESSION['email'];

        $sql="SELECT nom_etudiant, photo FROM etudiant WHERE email = '$i'";
        
        
        //include "../php/requetes/db-connexion.php";
        
        $link = "<li><a href='assets/views/ajouter.php'>ADD</a></li><li><a href='assets/views/supprimer.php'>Delete</a></li><li><a href='assets/views/update.php'>Update</a></li>";
        
        $exe = mysqli_query($con,$sql);
        
        $sour="../../../php/requetes/basedeDonnees/";
        
        while($affiche=mysqli_fetch_array($exe))
            @$image = $affiche['photo'];
        $me = "<a href='../php/deconnexion/' id='compte' name='deconnexion'><img src='../php/requetes/basedeDonnees/".$image."' class='fermer'>Deconnexion</a>";
    }else
        $me = "<li><a href='../views/signin.php'>Connexion</a></li>";
