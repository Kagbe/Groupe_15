<?php
@session_start();
        if (isset($_POST['btnsearch'])) {
            $elmt = $_POST['btnsearch'];
            include_once('connexion.php');
            $sql = "SELECT * FROM all_ordinateur WHERE marque='$elmt'";
            $exe = mysqli_query($con,$sql);
            while($affiche = mysqli_fetch_array($exe)){
    ?>   
                <div class="flex admin-container">
                    <section class="flex-1">
                        <input type="text" placeholder="Marque" name="mark" value="<?php echo $affiche['marque'];?>">
                        <input type="text" placeholder="Modele" name="modele" value="<?php echo $affiche['modele'];?>">
                        <input type="number" placeholder="Prix" name="prix" value="<?php echo $affiche['prix'];?>">
                        <input type="text" placeholder="Ecran en ''" name="ecran" value="<?php echo $affiche['ecran'];?>">
                        <input type="number" placeholder="Disque" name="disk" value="<?php echo $affiche['disque'];?>">
                        <input type="number" placeholder="Processeur" name="proces" value="<?php echo $affiche['processeur'];?>">
                        <input type="submit" name="butn" value="Supprimer">
                    </section>
                    <section class="flex-1">
                        <article><img src="<?php echo "php/requetes/basedeDonnees/".$affiche['photo'];?>"></article>
                        <textarea name="descriptionO" id=""><?php echo $affiche['descriptionOrd'];?></textarea>
                    </section>
                </div>

            <?php 
            }
}
       @$p = $_POST['mark'];
        if (isset($_POST['butn']) && !empty($_POST['btnsearch'])) {
            $sql = "DELETE FROM all_ordinateur WHERE marque='$p'";
            $exe = mysqli_query($con,$sql);
            header("location: http://localhost/projet_ecommerce/supprimer.php?erreur=Supprimer avec success...");
        }
    ?>