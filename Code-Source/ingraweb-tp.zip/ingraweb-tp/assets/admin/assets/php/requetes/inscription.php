<?php 
    session_start();
    if (isset($_POST['btn'])) {
        $nm = $_POST['nom'];



        $img = $_FILES['image']['name'];
        $taille = $_FILES['image']['size'];
        $error = $_FILES['image']['error'];
        $type = $_FILES['image']['type'];
        $sourc = $_FILES['image']['tmp_name'];
        $extenTab = ['jpg','jpeg','png','bmp','gif','tif'];
        $extF=strtolower(end(explode('.',$img)));

        $pom = $_POST['prenom'];
        $ps = $_POST['pays'];
        $sx = $_POST['sexe'];
        $pwd = $_POST['pwd'];
        include_once('connexion.php');
        if ($error==0 && $taille < 100001100) {
            if (in_array($extF,$extenTab)) {
                $photo = uniqid("",true);
                $photo = $photo.'.'.$extF;
                if (move_uploaded_file($sourc, "basedeDonnees/".$photo)) {
                    $sql = "INSERT INTO users (nom,prenom,sexe,pays,pass,photo) VALUES ('$nm','$pom','$sx','$ps','$pwd','$photo')";
                    $exe = mysqli_query($con,$sql) or die("Echec d'incription ...");
                    if ($exe){
                        $_SESSION['nom'] = $nm;
                        header ("Location: ../../index.php"); 
                    }
                }else
                    header("location: http://localhost/projet_ecommerce/inscription.php?erreur=Utilisateur non enregistre...");
            }else
                header("location: http://localhost/projet_ecommerce/inscription.php?erreur=Extension du fichier non autorisee...");
        }else
            header("location: http://localhost/projet_ecommerce/inscription.php?erreur=erreur sur le fichier ou taille trop importante...");
        mysqli_close($con);
    }
?>