<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="../css/sign/css/main.css">
</head>
<body>

    <header>
        <div class="banner-promo-container tc">
            <div class="container">
                <div class="banner-promo py-15">
                    Get Up to 40% OFF New-Season Style 
                    <span class="men">House</span>
                    * Limited time Only
                </div>
            </div>
        </div>
        <div class="nav-top-container">
            <div class="container">
                <div class="nav-top flex jcsb gap-15 py-15">
                    <div class="nav-message">FREE RETURN. STANDARD SHIPPING ORDER *99+</div>
                    <div class="nav-items">
                        <ul class="flex jcc gap-20">
                            <li><a href="#">My Account</a></li>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">My Wishlist</a></li>
                            <li><a href="#">Cart</a></li>
                            <li><a href="#">Log In</a></li>
                        </ul>
                    </div>
                    <div class="flex gap-10">
                        <div class="nav-country">
                            <select name="country" id="country">
                                <option value="france">FRA</option>
                                <option value="usa">USA</option>
                                <option value="rus">RUS</option>
                            </select>
                        </div>
                        <div class="nav-currency">
                            <select name="currency" id="currency">
                                <option value="EUR">EUR</option>
                                <option value="USD">USD</option>
                                <option value="OXF">OXF</option>
                            </select>
                        </div>
                    </div>
                    <div class="nav-social-icon flex gap-20">
                        <div class="social-icon-item">
                            <i class="bi bi-facebook"></i>
                        </div>
                        <div class="social-icon-item">
                            <i class="bi bi-twitter"></i>
                        </div>
                        <div class="social-icon-item">
                            <i class="bi bi-instagram"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="website-details-container box">
            <div class="container">
                <div class="website-details flex aic gap-10">
                    <i class="fa-solid fa-bars none" id="toggleMobileNav" data-mobile="mobile-nav"></i>
                    <div class="website-logo logo">
                        <h2>
                            <a href="../../">City Univ</a>
                        </h2>
                    </div>
                    <div class="website-search-bar flex-1 flex">
                        <input type="search" name="product_filter" id="product_filter" class="flex-1 px-20" placeholder="Search ...">
                        <select name="categories" id="categories">
                            <option value="">All categories</option>
                        </select>
                        <div class="search-icon flex aic jcc">
                            <i class="bi bi-search"></i>
                        </div>
                    </div>
                    <div class="website-call-us flex aic gap-10">
                        <div class="call-icon">
                            <i class="bi bi-telephone"></i>
                        </div>
                        <div class="call-message">
                            <h3>Call Us</h3>
                            <a href="tel:+123456789">+123456789</a>
                        </div>
                    </div>
                    <div class="website-icon flex gap-10">
                        <div class="website-icon-item">
                            <i class="bi bi-person"></i>
                        </div>
                        <div class="website-icon-item">
                            <i class="bi bi-bag-heart"></i>
                        </div>
                        <div class="website-icon-item">
                            <i class="bi bi-cart" data-mobile="mobile-cart" id="openCartO"></i>
                        </div>
                        <div class="website-icon-item">
                            <i class="bi bi-chevron-left" id="openCart" data-mobile="mobile-cart"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <nav>
        <div class="container">
            <div class="nav-container flex jcsb">
                <div class="nav-left">
                    <ul class="flex gap-10">
                        <li><a href="index.html" class="active">HOME</a></li>
                        <li class="relative">
                            <a href="#">CATEGORIES <i class="bi bi-chevron-down py-10 px-10"></i></a>
                            <div class="mega-sub-nav absolute flex box">
                                <div class="mega-item">
                                    <h3>Variation 1</h3>
                                    <ul>
                                        <li><a href="#">Fullwidth Banner</a></li>
                                        <li><a href="#">Boxed Slider Banner</a></li>
                                        <li><a href="#">Boxed Image Banner</a></li>
                                        <li><a href="#">Left Sidebar</a></li>
                                        <li><a href="#">Right Sidebar</a></li>
                                        <li><a href="#">Off Canvas Filter</a></li>
                                        <li><a href="#">Horizontal Filter1</a></li>
                                        <li><a href="#">Horizontal Filter2</a></li>
                                    </ul>
                                </div>
                                <div class="mega-item">
                                    <h3>Variation 2</h3>
                                    <ul>
                                        <li><a href="#">List types</a></li>
                                        <li><a href="#">Ajax Infinite Scroll</a></li>
                                        <li><a href="#">3 Columns Products</a></li>
                                        <li><a href="#">4 Columns Products</a></li>
                                        <li><a href="#">5 Columns Products</a></li>
                                        <li><a href="#">6 Columns Products</a></li>
                                        <li><a href="#">7 Columns Products</a></li>
                                        <li><a href="#">8 Columns Products</a></li>
                                    </ul>
                                </div>
                                <div class="mega-item relative">
                                    <img src="../images/blog-2.jpg" alt="image de promotion">
                                    <div class="mega-item-content absolute">
                                        <span>OFF</span>
                                        <div>
                                            <h4>UP TO</h4>
                                            <h3>50%</h3>
                                        </div>
                                    </div>
                                    <button class="btn absolute">SHOP NOW</button>
                                </div>
                            </div>
                        </li>
                        <li class="relative">
                            <a href="#">PRODUCTS <i class="bi bi-chevron-down py-10 px-10"></i></a>
                            <div class="mega-sub-nav absolute flex box">
                                <div class="mega-item">
                                    <h3>Product Pages</h3>
                                    <ul>
                                        <li><a href="#">Simple Product</a></li>
                                        <li><a href="#">Variable Product</a></li>
                                        <li><a href="#">Sale Product</a></li>
                                        <li><a href="#">Featured & on Sale</a></li>
                                        <li><a href="#">With Custom Tab</a></li>
                                        <li><a href="#">With Left Sidebar</a></li>
                                        <li><a href="#">With Right Sidebar</a></li>
                                        <li><a href="#">Add Cart Sticky</a></li>
                                    </ul>
                                </div>
                                <div class="mega-item">
                                    <h3>Product Layots</h3>
                                    <ul>
                                        <li><a href="#">Extended Layout</a></li>
                                        <li><a href="#">Grip Image</a></li>
                                        <li><a href="#">Full Width Layout</a></li>
                                        <li><a href="#">Sticky Info</a></li>
                                        <li><a href="#">Left & Right Sticky</a></li>
                                        <li><a href="#">Transparent Image</a></li>
                                        <li><a href="#">Center Vertical</a></li>
                                        <li><a href="#">Build Your Own</a></li>
                                    </ul>
                                </div>
                                <div class="mega-item relative">
                                    <img src="../images/hero-banner.png" alt="image de promotion">
                                    <div class="mega-item-content absolute">
                                        <span>OFF</span>
                                        <div>
                                            <h4>UP TO</h4>
                                            <h3>50%</h3>
                                        </div>
                                    </div>
                                    <button class="btn absolute">SHOP NOW</button>
                                </div>
                            </div>
                        </li>
                        <li class="relative">
                            <a href="#">PAGES <i class="bi bi-chevron-down py-10 px-10"></i></a>
                            <ul class="sub-nav absolute box none">
                                <li><a href="#">Wishlist</a></li>
                                <li><a href="#">Shopping Cart</a></li>
                                <li><a href="#">Checkout</a></li>
                                <li><a href="#">DashBoard</a></li>
                                <li><a href="#">About Us</a></li>
                                <li class="relative">
                                    <a href="#">Blog <i class="bi bi-chevron-down py-10 px-10"></i></a>
                                    <ul class="sub-nav absolute box none">
                                        <li><a href="#">Blog </a></li>
                                        <li><a href="#">Blog Post</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Login</a></li>
                                <li><a href="#">Forgot Password</a></li>
                            </ul>
                        </li>
                        <li><a href="#">BLOG</a></li>
                        <li><a href="#">ELEMENTS</a></li>
                        <li><a href="#">CONTACT US</a></li>
                    </ul>
                </div>
                <div class="nav-right">
                    <ul class="flex gap-10">
                        <li><a href="#">special offer !</a></li>
                        <li><a href="#">Buy PORTO !</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- NAV BAR POUR LES MOBILES -->
    <div class="mobile mobile-nav mobile-left none">
        <div class="overlay"></div>
        <div class="mobile-content fixed">
            <div class="mobile-content-header relative">
                <div class="mobile-title">
                    <h2>City Univ</h2>
                </div>
                <div class="mobile-close absolute" data-mobile="mobile-nav">
                    <img src="/css/sign/images/icons/close.png" data-mobile="mobile-nav" alt="">
                </div>
            </div>
            <div class="mobile-content-body">
                <ul>
                    <li class="mobile-nav-item"><a href="../../">Home</a></li>
                    <li class="mobile-nav-item"><a href="#">Categories</a></li>
                    <li class="mobile-nav-item active"><a href="#">Products</a></li>
                    <li class="mobile-nav-item"><a href="#">Pages</a></li>
                    <li class="mobile-nav-item"><a href="#">Blog</a></li>
                    <li class="mobile-nav-item"><a href="#">Elements</a></li>
                    <li class="mobile-nav-item"><a href="#">Contact Us</a></li>
                    <li class="mobile-nav-item"><a href="signup.html">Sign Up</a></li>
                </ul>
            </div>
            <div class="mobile-content-footer"></div>
        </div>
    </div>

    <!-- NAV BAR POUR LE PANIER DE L'USER -->
    <div class="mobile mobile-cart cart mobile-right none">
        <div class="overlay"></div>
        <div class="mobile-content fixed">
            <div class="mobile-content-header relative">
                <div class="mobile-title">
                    <h2>City Univ</h2>
                </div>
                <div class="mobile-close absolute" data-mobile="mobile-cart">
                    <img src="/css/sign/images/icons/close.png" alt="" data-mobile="mobile-cart">
                </div>
            </div>
        </div>
    </div>


    <!-- SIGN IN -->
    <section id="sign">
        <div class="container">
            <form action="../php/requetes/connexion.php" method="post">
                <h1>Sign In</h1>
                <div class="form-inline">
                    <input type="email" placeholder="Your Email please ..." name = "email" required>
                </div>
                <div class="form-inline">
                    <input type="password" placeholder="Your password please ..." name = "password" required>
                </div>
                <div class="form-error">
                    <?php echo @$_GET['erreur'];?>
                </div>
                <div class="form-submit">
                    <button class="btn submit" name="btn" type="submit">Sign In</button>
                </div>
                <p>You don't have account ? please <a href="signup.php">click here</a> to create an account. </p>
            </form>
        </div>
    </section>

    <footer class="py-50">
        <div class="container">
            <div class="footer-content flex jcsb wrap pb-30">
                <div class="footer-list">
                    <h2>Contact Infos</h2>
                    <div class="footer-item">
                        <h4>Adresse : </h4>
                        <p>123 Street Name, City, Egland</p>
                    </div>
                    <div class="footer-item">
                        <h4>Phone : </h4>
                        <p>(123) 456-8960</p>
                    </div>
                    <div class="footer-item">
                        <h4>Email : </h4>
                        <p>mail@example.com</p>
                    </div>
                    <div class="footer-item">
                        <h4>Working Days/Hours : </h4>
                        <p>Mon - Sun / 9:00 AM - 8:00 PM</p>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Customers Service</h2>
                    <ul>
                        <li class="customer-service-item"><a href="#">Help & FAQs</a></li>
                        <li class="customer-service-item"><a href="#">Order Tracking</a></li>
                        <li class="customer-service-item"><a href="#">Shipping & Delivery</a></li>
                        <li class="customer-service-item"><a href="#">Orders History</a></li>
                        <li class="customer-service-item"><a href="#">Advanced Search</a></li>
                        <li class="customer-service-item"><a href="#">My Account</a></li>
                        <li class="customer-service-item"><a href="#">Careers</a></li>
                        <li class="customer-service-item"><a href="#">About Us</a></li>
                        <li class="customer-service-item"><a href="#">Corporate Sales</a></li>
                        <li class="customer-service-item"><a href="#">Privacy</a></li>
                    </ul>
                </div>
                <div class="footer-list">
                    <h2>Popular Tags</h2>
                    <div class="footer-tags flex wrap gap-5">
                        <div class="tags">bags</div>
                        <div class="tags">black</div>
                        <div class="tags">blue</div>
                        <div class="tags">clothes</div>
                        <div class="tags">Fashion</div>
                        <div class="tags">Hub</div>
                        <div class="tags">Shirt</div>
                        <div class="tags">Shoes</div>
                        <div class="tags">Skirt</div>
                    </div>
                </div>
                <div class="footer-list">
                    <h2>Subscribe Newsletter</h2>
                    <div class="footer-subscribe">
                        <p>
                            Get all the latest information on events, sales and offers. Sign up for newsletter:
                        </p>
                        <div class="footer-input">
                            <input type="email" name="email" id="email" placeholder="Email Address">
                        </div>
                        <button class="btn">Subscribe</button>
                    </div>
                </div>
            </div>
            <div class="footer-bottom flex jcsb py-30 wrap gap-10">
                <div class="footer-bottom-left">
                    © City Univ. 2024. All Rights Reserved
                </div>
                <div class="footer-bottom-right flex gap-10">
                    <img src="assets/images/card/mastercard.svg" alt="">
                    <img src="assets/images/card/cb.svg" alt="">
                    <img src="assets/images/card/visa.svg" alt="">
                    <img src="assets/images/card/oney.svg" alt="">
                </div>
            </div>
        </div>
    </footer>

    <script src="../css/sign/js/main.js"></script>
</body>
</html>