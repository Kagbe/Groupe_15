<?php
/*
	connexion avec la methode simple
*/
    $con = mysqli_connect('127.0.0.1', 'root', '','db_cite_univ') or die ("Echec de connexion...");


/*
	connexion avec la methode PDO
*/
    $bd = new PDO('mysql:host=localhost;dbname=db_cite_univ;charset=utf8;','root','') or die ("Echec de connexion...");
?>