<?php
                /*
                    Get Error on slug or url with get Metod
                */
                    echo "Paiement reussi...";
                    echo "<a class='' href='http://localhost/ingraweb-tp/'>Retour acceuil</a>"
?>