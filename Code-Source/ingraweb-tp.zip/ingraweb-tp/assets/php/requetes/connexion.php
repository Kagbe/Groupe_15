<?php
    session_start();
    if (isset($_POST['btn'])) {
    	$email = $_POST['email'];
    	$pwd = $_POST['password'];
    	if (!empty($email)) {
	    	
			
			include_once("db-connexion.php");
		    
			
			$exe = $bd -> prepare('SELECT email, matricule_etudiant FROM etudiant WHERE email= ? AND matricule_etudiant= ?');
		    $exe -> execute(array($email, $pwd));
		    if ($exe -> rowCount() > 0) {
		    	$_SESSION['email'] = $email;
		    	$_SESSION['password'] = $pwd;


				if ($email == "admin@admin.com" && $pwd = "admin") {
					
					header("location: http://localhost/ingraweb-tp/assets/admin/");
				}else
		    		header("location: http://localhost/ingraweb-tp/");
		    }else{
		    	header("location: http://localhost/ingraweb-tp/assets/views/signin.php?erreur=Votre mot de passe ou email est incorrect ...");
			}
		}else{
    		header("location: http://localhost/ingraweb-tp/assets/views/signin.php?erreur=Remplir tous les champs ...");
		}
    }
?>