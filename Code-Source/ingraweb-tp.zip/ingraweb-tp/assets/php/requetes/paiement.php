<?php 
    session_start();


    if (isset($_POST['btn'])) {

        // recuperation des donnees
        $email     =  $_SESSION['email'];
        $number     = $_POST['cartNumber'];
        $dateMois = $_POST['mois'];
        $dateAnnee = $_POST['annee'];
        $code    = $_POST['code'];
        // fin de recuperation des donnes
        
        include_once('db-connexion.php');
        $date = $dateMois.'/'.$dateAnnee;
        if (!empty($number) && !empty($date) && !empty($code)) {
            
                    $sql = "INSERT INTO banque (email,numberCarte,dateCarte, code) VALUES ('$email','$number','$date','$code')";
                    $exe = mysqli_query($con,$sql) or die("Echec d'incription ...");
                    if ($exe){
                        $_SESSION['email'] = $email;
                        header ("Location: http://localhost/ingraweb-tp/assets/php/requetes/sucess.php"); 
                    }
        }else{
            header("location: http://localhost/ingraweb-tp/assets/php/requetes/error.php?erreur= Remplissez tout le formulaire...");
        }
        
            mysqli_close($con);
    }
