<?php 
    session_start();
    if (isset($_POST['btn'])) {
        $nm = $_POST['nom'];


        // recuperation de l'image
        $img      = $_FILES['image']['name'];
        $taille   = $_FILES['image']['size'];
        $error    = $_FILES['image']['error'];
        $type     = $_FILES['image']['type'];
        $sourc    = $_FILES['image']['tmp_name'];
        $extenTab = ['jpg','jpeg','png','bmp','gif','tif'];
        $extF     = strtolower(end(explode('.',$img)));
        // fin de recuperation

        // recuperation des donnees
        $name     = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email    = $_POST['email'];
            // verification password
        $pwd1     = $_POST['password1'];
        $pwd2     = $_POST['password2'];
        // fin de recuperation des donnes

        include_once('db-connexion.php');
        if ($pwd1 == $pwd2) {
            $password = $pwd1;
        
        if ($error==0 && $taille < 100001100) {
            if (in_array($extF, $extenTab)) {
                $photo = uniqid("",true);
                $photo = $photo.'.'.$extF;
                if (move_uploaded_file($sourc, "basedeDonnees/".$photo)) {
                    $sql = "INSERT INTO etudiant (nom_etudiant,prenom_etudiant,email, matricule_etudiant,photo) VALUES ('$name','$lastname','$email','$password','$photo')";
                    $exe = mysqli_query($con,$sql) or die("Echec d'incription ...");
                    if ($exe){
                        $_SESSION['email'] = $email;
                        header ("Location: http://localhost/ingraweb-tp/assets/views/signin.php"); 
                    }
                }else
                    header("location: http://localhost/ingraweb-tp/assets/views/signup.php?erreur=Utilisateur non enregistre...");
            }else
                header("location: http://localhost/ingraweb-tp/assets/views/signup.php?erreur=Extension du fichier non autorisee...");
        }else
            header("location: http://localhost/ingraweb-tp/assets/views/signup.php?erreur=Erreur sur le fichier ou taille trop importante...");
        }else{
            header("location: http://localhost/ingraweb-tp/assets/views/signup.php?erreur=Erreur verifier le mot de passe...");
        }
        
            mysqli_close($con);
    }
