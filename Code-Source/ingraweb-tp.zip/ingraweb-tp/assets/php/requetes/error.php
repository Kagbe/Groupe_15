<?php
                /*
                    Get Error on slug or url with get Metod
                */
                    echo "Echec de paiement...";

                    $error = $_GET['erreur'];
                    echo "<br/>".$error;
                    //echo "<a class='' href='http://localhost/ingraweb-tp/'>Retour acceuil</a>"
?>