<?php
/*
	Get Error on slug or url with get Metod
*/
echo @$_GET['erreur'];