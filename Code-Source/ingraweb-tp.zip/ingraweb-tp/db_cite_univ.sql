-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 07 juin 2024 à 11:34
-- Version du serveur : 10.4.25-MariaDB
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `db_cite_univ`
--

-- --------------------------------------------------------

--
-- Structure de la table `banque`
--

CREATE TABLE `banque` (
  `id_banque` int(11) NOT NULL,
  `idEtudiant` int(11) DEFAULT NULL,
  `nom_banque` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `numberCarte` varchar(255) NOT NULL,
  `dateCarte` varchar(255) NOT NULL,
  `code` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `banque`
--

INSERT INTO `banque` (`id_banque`, `idEtudiant`, `nom_banque`, `email`, `numberCarte`, `dateCarte`, `code`) VALUES
(1, NULL, '', '', '345', '/', '54'),
(2, NULL, '', '', '46', 'Janvier/2024', '4'),
(3, NULL, '', '', '34', 'Janvier/2024', '56');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `id_category` int(11) NOT NULL,
  `nom_category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `chambre`
--

CREATE TABLE `chambre` (
  `id_chambre` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `id_category` int(11) DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  `idGestionnaire` int(11) DEFAULT NULL,
  `idEtudiant` int(11) DEFAULT NULL,
  `numero_chambre` varchar(5) NOT NULL,
  `lieu_chambre` varchar(100) DEFAULT NULL,
  `prix_chambre` varchar(20) NOT NULL,
  `surface` float NOT NULL,
  `description` text NOT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `id_etudiant` int(11) NOT NULL,
  `idGestionnaire` int(11) DEFAULT NULL,
  `matricule_etudiant` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nom_etudiant` varchar(100) NOT NULL,
  `prenom_etudiant` varchar(100) DEFAULT NULL,
  `tel_etudiant` varchar(15) DEFAULT NULL,
  `nationnalite_etudiant` varchar(100) DEFAULT NULL,
  `genre_etudiant` varchar(10) DEFAULT NULL,
  `photo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id_etudiant`, `idGestionnaire`, `matricule_etudiant`, `email`, `nom_etudiant`, `prenom_etudiant`, `tel_etudiant`, `nationnalite_etudiant`, `genre_etudiant`, `photo`) VALUES
(7, NULL, 'aa', 'aa@aa', 'aa', 'aa', NULL, NULL, NULL, '6660660c005b59.55234343.jpg'),
(8, NULL, 'admin', 'admin@admin.com', 'admin', 'admin', NULL, NULL, NULL, '66607870e63885.57929156.png'),
(9, NULL, 'bouba', 'bouba@bouba.com', 'bouba', 'bouba', NULL, NULL, NULL, '66612dcd6d7001.96657659.jpg'),
(10, NULL, '77', 'bb@b', 'bb', 'bb', NULL, NULL, NULL, '66613382664b17.85364408.jpg'),
(11, NULL, '88', 'gil@l', 'gil', 'gil', NULL, NULL, NULL, '666137e5de1bb9.06158691.png');

-- --------------------------------------------------------

--
-- Structure de la table `gestionnaire`
--

CREATE TABLE `gestionnaire` (
  `id_gestion` int(11) NOT NULL,
  `nom_gestion` varchar(100) NOT NULL,
  `prenom_gestion` varchar(100) DEFAULT NULL,
  `tel_gestion` varchar(15) DEFAULT NULL,
  `nationnalite_gestion` varchar(100) DEFAULT NULL,
  `genre_gestion` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `banque`
--
ALTER TABLE `banque`
  ADD PRIMARY KEY (`id_banque`),
  ADD KEY `idEtudiant` (`idEtudiant`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Index pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD PRIMARY KEY (`id_chambre`),
  ADD KEY `id_category` (`id_category`),
  ADD KEY `idGestionnaire` (`idGestionnaire`),
  ADD KEY `idEtudiant` (`idEtudiant`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`id_etudiant`),
  ADD KEY `idGestionnaire` (`idGestionnaire`);

--
-- Index pour la table `gestionnaire`
--
ALTER TABLE `gestionnaire`
  ADD PRIMARY KEY (`id_gestion`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `banque`
--
ALTER TABLE `banque`
  MODIFY `id_banque` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `category`
--
ALTER TABLE `category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `chambre`
--
ALTER TABLE `chambre`
  MODIFY `id_chambre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `etudiant`
--
ALTER TABLE `etudiant`
  MODIFY `id_etudiant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `gestionnaire`
--
ALTER TABLE `gestionnaire`
  MODIFY `id_gestion` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `banque`
--
ALTER TABLE `banque`
  ADD CONSTRAINT `banque_ibfk_1` FOREIGN KEY (`idEtudiant`) REFERENCES `etudiant` (`id_etudiant`) ON DELETE SET NULL;

--
-- Contraintes pour la table `chambre`
--
ALTER TABLE `chambre`
  ADD CONSTRAINT `chambre_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id_category`) ON DELETE SET NULL,
  ADD CONSTRAINT `chambre_ibfk_2` FOREIGN KEY (`idGestionnaire`) REFERENCES `gestionnaire` (`id_gestion`) ON DELETE SET NULL,
  ADD CONSTRAINT `chambre_ibfk_3` FOREIGN KEY (`idEtudiant`) REFERENCES `etudiant` (`id_etudiant`) ON DELETE SET NULL;

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `etudiant_ibfk_1` FOREIGN KEY (`idGestionnaire`) REFERENCES `gestionnaire` (`id_gestion`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
