<?php session_start();?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>location des cités-U</title>


  <link rel="shortcut icon" href="../images/favicon.svg" type="image/svg+xml">

  <link rel="stylesheet" href="assets/css/main.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet">

</head>

<body>

  <header class="header" data-header>

    <div class="overlay" data-overlay></div>

    <div class="header-top">
      <div class="container">
        <ul class="header-top-list">
          <li>
            <a href="mailto:kagbemathias3@gmail.com" class="header-top-link">
              <ion-icon name="mail-outline"></ion-icon>
              <span>univ-ndere444@gmail.com</span>
            </a>
          </li>
          <li>
            <a href="#" class="header-top-link">
              <ion-icon name="location-outline"></ion-icon>
              <address>15/A, Ngaoundéré, NDERE</address>
            </a>
          </li>
        </ul>
        <div class="wrapper">
          <ul class="header-top-social-list">
            <li>
              <a href="#" class="header-top-social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>
            <li>
              <a href="#" class="header-top-social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>
            <li>
              <a href="#" class="header-top-social-link">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>
            <li>
              <a href="#" class="header-top-social-link">
                <ion-icon name="logo-pinterest"></ion-icon>
              </a>
            </li>
          </ul>
          <button class="header-top-btn">
            Ajouter une Annonce
          </button>
        </div>
      </div>
    </div>
    <div class="header-bottom">
      <div class="container">
        <a href="#" class="logo">
          <img src="assets/images/logo.png" alt="logo de la cité">
        </a>
        <nav class="navbar" data-navbar>
          <div class="navbar-top">
            <a href="#" class="logo">
              <img src="assets/images/logo.png" alt="logo de la cité">
            </a>
            <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
              <ion-icon name="close-outline"></ion-icon>
            </button>
          </div>
          <div class="navbar-bottom">
            <ul class="navbar-list">
              <li>
                <a href="#about" class="navbar-link" data-nav-link>A propos</a>
              </li>
              <li>
                <a href="#service" class="navbar-link" data-nav-link>Service</a>
              </li>
              <li>
                <a href="#property" class="navbar-link" data-nav-link>Propriété</a>
              </li>
              <li>
                <a href="#blog" class="navbar-link" data-nav-link>Blog</a>
              </li>
              <li>
                <a href="#contact" class="navbar-link" data-nav-link>Contact</a>
              </li>
            </ul>
          </div>
        </nav>
        <div class="header-bottom-actions">

          <button class="header-botton-actions-btn" aria-label="Search">
            <ion-icon name="search-outline"></ion-icon>

            <span>Recherche</span>
          </button>
          <button class="header-botton-actions-btn" aria-label="Profile">
            <?php 
            /*echo "<script>
                      const a = document.querySelector('#connexion')
                      const b = document.querySelector('#deconnexion')
            
                      b.style.display='none'
                </script>";*/
            if (!empty($_SESSION['email'])) {
                $a =  "<a href='assets/php/deconnexion/index.html' id='dec'><ion-icon name='person-outline'></ion-icon><span>Se deconnecter</span>
                </a>";
              }else{
                $a = "<a href='assets/views/signin.php' id='con'><ion-icon name='person-outline'></ion-icon><span>Se conecter</span></a>";
              }
            


              echo $a;
            ?>
            
              
            
          </button>
          <button class="header-botton-actions-btn" aria-label="Cart">
            <a href="assets/views/panier.html">
            <ion-icon name="cart-outline" id="openCart" data-mobile="mobile-cart"></ion-icon>
             <span>Panier</span>
            </a>
          </button>
          <button class="header-botton-actions-btn" data-nav-open-btn aria-label="Open Menu">
            <ion-icon name="menu-outline"></ion-icon>

            <span>Menu</span>
          </button>
        </div>

      </div>
    </div>
  </header>



  <main>
    <article>
      <section class="hero" id="home">
        <div class="container">
          <div class="hero-content">

            <p class="hero-subtitle">

              <ion-icon name="home"></ion-icon>

              <span> Location des Chambres de Cité-U </span>
            </p>
            <h2 class="h1 hero-title">Trouver la Maison <span class="multiText">OP</span></h2>
            <p class="hero-text">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
              ut labore
            </p>
            <button class="btn">se renseigner</button>
          </div>
          <figure class="hero-banner">
            <!-- <img src="/images/hero-banner.png" alt="Modern house model" class="w-100"> -->
            <div class="body">

              <div id="carousel">
                <div class="images">
                  <img src="assets/images//images/batimrnt1.png" alt="batiment" class="w-10">
                  <img src="assets/images//images/batiment2.png" alt="batiment" class="w-10">
                  <img src="assets/images//images/batiment3.png" alt="" class="w-10">
                  <img src="assets/images//images/about-banner-1.png" alt="batiment" class="w-10">
                  <img src="assets/images//images/blog-1.png" alt="batiment" class="w-10">
                  <img src="assets/images//images/property-2.jpg" alt="batiment" class="w-10">

                </div>
              </div>
            </div>
          </figure>
        </div>
      </section>

      <!-- partie de about -->
      <section class="about" id="about">

        <div class="container">

          <figure class="about-banner">
            <img src="assets/images/about-banner-1.png" alt="l'interieur de la maison ">

            <img src="assets/images/about-banner-2.jpg" alt="l'interieur de la maison" class="abs-img">
          </figure>

          <div class="about-content">

            <p class="section-subtible"> A Propos-Nous </p>

            <h2 class="h2 section-title">Spécialement pour la location de chambres de cité-U(université de Ngaoundéré) .
            </h2>

            <p class="about-text">
              Plus de 2 000 étudiants louent les chambres chaque année
              et à la sortie,sont satisfait de l'état de chaque chambre.

            </p>

            <ul class="about-list">
              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="home-outline"></ion-icon>
                </div>
                <p class="about-item-text">Chambres Equipées</p>
              </li>
              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="leaf-outline"></ion-icon>
                </div>
                <p class="about-item-text">Alentours Propres</p>
              </li>
              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="wine-outline"></ion-icon>
                </div>
                <p class="about-item-text">Bien Construites</p>
              </li>
              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="shield-checkmark-outline"></ion-icon>
                </div>
                <p class="about-item-text">Sécurité complète 24h/24 et 7j/7</p>
              </li>
            </ul>

            <p class="callout">
              "Enimad minim veniam quis nostrud exercitation
              llamco laboris. Lorem ipsum dolor sit amet"
            </p>

            <a href="#service" class="btn">Nos services</a>

          </div>
        </div>
      </section>

      <!-- partie de services -->

      <section class="sercice" id="service">
        <div class="container">
          <p class="section-subtitle">Nos Services</p>

          <h2 class="h2 section-title">Notre objectif principal</h2>
          <ul class="service-list">
            <li>
              <div class="service-card">

                <div class="card-icon">

                  <img src="assets/images/service-1.png" alt="icone de service">

                </div>
                <h3 class="h3 card-title">
                  <a href="#">Location des Chambres</a>
                </h3>

                <p class="card-text">
                  Plusieurs de chambres disponibles,nous vous proposons quelques chambres
                  en image que vous pouvez voir maintenant.
                </p>

                <a href="#" class="card-link">
                  <span>Trouver une chambre</span>

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </a>
              </div>
            </li>
            <li>
              <div class="service-card">

                <div class="card-icon">

                  <img src="assets/images/service-2.png" alt="icone de service">

                </div>
                <h3 class="h3 card-title">
                  <a href="#">Louer une Chambre</a>
                </h3>

                <p class="card-text">
                  Plusieurs de chambres disponibles,nous vous
                  proposons quelques chambres
                  en image que vous pouvez voir maintenant.
                </p>

                <a href="#" class="card-link">
                  <span>Trouver une chambre</span>

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </a>
              </div>
            </li>
            <li>
              <div class="service-card">

                <div class="card-icon">

                  <img src="assets/images/service-3.png" alt="icone de service">

                </div>
                <h3 class="h3 card-title">
                  <a href="#">Chambre Louée Déjà</a>
                </h3>

                <p class="card-text">
                  Plusieurs de chambres disponibles,nous
                  vous proposons quelques chambres
                  en image que vous pouvez voir maintenant.
                </p>

                <a href="#" class="card-link">
                  <span>Trouver une chambre</span>
                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </a>
              </div>
            </li>

          </ul>
        </div>
      </section>

      <!-- property -->

      <section class="property" id="property">
        <div class="container">
          <p class="section-subtitle">Propriétés</p>

          <h2 class="h2 section-title">Annonces en vedette</h2>

          <ul class="property-list has-scrollbar">

            <li>
              <div class="property-card">
                <figure class="card-banner">
                  <a href="#">
                    <img src="assets/images/property-1.jpg" alt="New Apartment Nice View" class="w-100">
                  </a>

                  <div class="card-badge green">A louer</div>

                  <div class="banner-actions">

                    <button class="banner-actions-btn">

                      <ion-icon name="location"></ion-icon>

                      <address>Cité-U, Ngaoundéré</address>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="camera"></ion-icon>

                      <span>4</span>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="film"></ion-icon>

                      <span>2</span>
                    </button>
                  </div>
                </figure>

                <div class="card-content">

                  <div class="card-price">
                    <strong>$0350</strong>/Moi
                  </div>

                  <h3 class="h3 card-title">
                    <a href="#">Appartement Neuf, Belle Vue</a>
                  </h3>

                  <p class="card-text">
                    Belle immense maison 1 famille au coeur de l'Université.
                    Récemment rénové avec du bois neuf!
                  </p>

                  <ul class="card-list">
                    <li class="card-item">
                      <strong>3</strong>

                      <ion-icon name="bed-outline"></ion-icon>

                      <span>Chambres</span>
                    </li>
                    <li class="card-item">
                      <strong>2</strong>

                      <ion-icon name="man-outline"></ion-icon>

                      <span>Salles de bains</span>
                    </li>
                    <li class="card-item">
                      <strong>3450</strong>

                      <ion-icon name="square-outline"></ion-icon>

                      <span>Carré Ft</span>
                    </li>
                  </ul>
                </div>

                <div class="card-footer">

                  <div class="card-author">

                    <figure class="author-avatar">
                      <img src="assets/images/Author2.jpg" alt="William Seklo" class="w-100">

                    </figure>

                    <div>
                      <p class="author-name">
                        <a href="#">ABAKAI EBENEZER</a>
                      </p>

                      <P class="author-title">Agent d'Entretien</P>
                    </div>

                  </div>

                  <div class="card-footer-actions">
                    <button class="card-footer-actions-btn">
                      <ion-icon name="resize-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="heart-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="add-circle-outline"></ion-icon>
                    </button>
                  </div>

                </div>

              </div>
            </li>
            <li>
              <div class="property-card">
                <figure class="card-banner">
                  <a href="#">
                    <img src="assets/images/property-2.jpg" alt=" Modern Apartments" class="w-100">
                  </a>

                  <div class="card-badge orange">Déja Louée</div>

                  <div class="banner-actions">

                    <button class="banner-actions-btn">

                      <ion-icon name="location"></ion-icon>

                      <address>Cité-U, Ngaoundéré</address>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="camera"></ion-icon>

                      <span>2</span>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="film"></ion-icon>

                      <span>1</span>
                    </button>
                  </div>
                </figure>

                <div class="card-content">

                  <div class="card-price">
                    <strong>$0100</strong>/Moi
                  </div>

                  <h3 class="h3 card-title">
                    <a href="#">Chambre moderne</a>
                  </h3>

                  <p class="card-text">
                    Belle immense chambre équipée,située au coeur de l'Université. Récemment rénové avec du bois neuf!
                  </p>

                  <ul class="card-list">
                    <li class="card-item">
                      <strong>2</strong>

                      <ion-icon name="bed-outline"></ion-icon>

                      <span>Chambres</span>
                    </li>
                    <li class="card-item">
                      <strong>1</strong>

                      <ion-icon name="man-outline"></ion-icon>

                      <span>Salles de bains</span>
                    </li>
                    <li class="card-item">
                      <strong>100</strong>

                      <ion-icon name="square-outline"></ion-icon>

                      <span>Carré Ft</span>
                    </li>
                  </ul>
                </div>

                <div class="card-footer">

                  <div class="card-author">

                    <figure class="author-avatar">
                      <img src="assets/images/Author1.jpg" alt="William Seklo" class="w-100">

                    </figure>

                    <div>
                      <p class="author-name">
                        <a href="#">KAGBE MATHIAS </a>
                      </p>

                      <P class="author-title">Agent d'Entretien</P>
                    </div>

                  </div>

                  <div class="card-footer-actions">
                    <button class="card-footer-actions-btn">
                      <ion-icon name="resize-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="heart-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="add-circle-outline"></ion-icon>
                    </button>
                  </div>

                </div>

              </div>
            </li>
            <li>
              <div class="property-card">
                <figure class="card-banner">
                  <a href="#">
                    <img src="assets/images/property-3.jpg" alt="Comfortable Apartment" class="w-100">
                  </a>

                  <div class="card-badge green">A louer</div>

                  <div class="banner-actions">

                    <button class="banner-actions-btn">

                      <ion-icon name="location"></ion-icon>

                      <address>Cité-U, Ngaoundéré</address>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="camera"></ion-icon>

                      <span>10</span>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="film"></ion-icon>

                      <span>8</span>
                    </button>
                  </div>
                </figure>

                <div class="card-content">

                  <div class="card-price">
                    <strong>$0900</strong>/Moi
                  </div>

                  <h3 class="h3 card-title">
                    <a href="#">Appartement confortable</a>
                  </h3>

                  <p class="card-text">
                    Belle immense maison pour les étudiants habitant en famille, située au coeur de l'Université
                    . Récemment réfectionnée avec du bois neuf.
                  </p>

                  <ul class="card-list">
                    <li class="card-item">
                      <strong>8</strong>

                      <ion-icon name="bed-outline"></ion-icon>

                      <span>Chambres</span>
                    </li>
                    <li class="card-item">
                      <strong>4</strong>

                      <ion-icon name="man-outline"></ion-icon>

                      <span>Salles de bains</span>
                    </li>
                    <li class="card-item">
                      <strong>8450</strong>

                      <ion-icon name="square-outline"></ion-icon>

                      <span>Carré Ft</span>
                    </li>
                  </ul>
                </div>

                <div class="card-footer">

                  <div class="card-author">

                    <figure class="author-avatar">
                      <img src="assets/images/Author3.jpg" alt="William Seklo" class="w-100">

                    </figure>

                    <div>
                      <p class="author-name">
                        <a href="#">BOUBA GILBERT</a>
                      </p>

                      <P class="author-title">Agent d'Entretien</P>
                    </div>

                  </div>

                  <div class="card-footer-actions">
                    <button class="card-footer-actions-btn">
                      <ion-icon name="resize-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="heart-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="add-circle-outline"></ion-icon>
                    </button>
                  </div>

                </div>

              </div>
            </li>
            <li>
              <div class="property-card">
                <figure class="card-banner">
                  <a href="#">
                    <img src="assets/images/property-4.png" alt=" Luxury villa in Rego Park" class="w-100">
                  </a>

                  <div class="card-badge green">A louer</div>

                  <div class="banner-actions">

                    <button class="banner-actions-btn">

                      <ion-icon name="location"></ion-icon>

                      <address>Cité-U, Ngaoundéré</address>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="camera"></ion-icon>

                      <span>6</span>
                    </button>
                    <button class="banner-actions-btn">

                      <ion-icon name="film"></ion-icon>

                      <span>3</span>
                    </button>
                  </div>
                </figure>

                <div class="card-content">

                  <div class="card-price">
                    <strong>$0600</strong>/Moi
                  </div>

                  <h3 class="h3 card-title">
                    <a href="#">Villa de luxe à Rego Park</a>
                  </h3>

                  <p class="card-text">
                    Belle immense maison pour les étudiants habitant en famille, située au coeur de l'Université
                    . Récemment réfectionnée avec du bois neuf.
                  </p>

                  <ul class="card-list">
                    <li class="card-item">
                      <strong>5</strong>

                      <ion-icon name="bed-outline"></ion-icon>

                      <span>Chambres</span>
                    </li>
                    <li class="card-item">
                      <strong>3</strong>

                      <ion-icon name="man-outline"></ion-icon>

                      <span>Salles de bains</span>
                    </li>
                    <li class="card-item">
                      <strong>4450</strong>

                      <ion-icon name="square-outline"></ion-icon>

                      <span>Carré Ft</span>
                    </li>
                  </ul>
                </div>

                <div class="card-footer">

                  <div class="card-author">

                    <figure class="author-avatar">
                      <img src="assets/images/Author.jpg" alt="William Seklo" class="w-100">

                    </figure>

                    <div>
                      <p class="author-name">
                        <a href="#">KOYAKOSSO- ESSO AMOS CHRISTOPHER</a>
                      </p>

                      <P class="author-title">Agent d'Entretien</P>
                    </div>

                  </div>

                  <div class="card-footer-actions">
                    <button class="card-footer-actions-btn">
                      <ion-icon name="resize-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="heart-outline"></ion-icon>
                    </button>
                    <button class="card-footer-actions-btn">
                      <ion-icon name="add-circle-outline"></ion-icon>
                    </button>
                  </div>

                </div>

              </div>
            </li>
          </ul>
        </div>
      </section>


      <!-- partie de features  -->
      <section class="features">

        <div class="container">
          <p class="section-subtitle">Nos Commodités</p>

          <h2 class="h2 section-title">Les Equipements Construits</h2>

          <ul class="features-list">

            <li>
              <a href="#" class="features-card">
                <div class="card-icon">
                  <ion-icon name="car-sport-outline"></ion-icon>
                </div>

                <h3 class="card-title">Place de Parking</h3>

                <div class="card-btn">

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </div>

              </a>
            </li>
            <li>
              <a href="#" class="features-card">
                <div class="card-icon">
                  <ion-icon name="shield-checkmark-outline"></ion-icon>
                </div>

                <h3 class="card-title">Sécurité Privée</h3>

                <div class="card-btn">

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </div>

              </a>
            </li>

            <li>
              <a href="#" class="features-card">
                <div class="card-icon">
                  <ion-icon name="fitness-outline"></ion-icon>
                </div>

                <h3 class="card-title">Centre Médical</h3>

                <div class="card-btn">

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </div>

              </a>
            </li>

            <li>
              <a href="#" class="features-card">
                <div class="card-icon">
                  <ion-icon name="library-outline"></ion-icon>
                </div>

                <h3 class="card-title">Espace Bibliothèque</h3>

                <div class="card-btn">

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </div>

              </a>
            </li>
            <li>
              <a href="#" class="features-card">
                <div class="card-icon">
                  <ion-icon name="football-outline"></ion-icon>
                </div>

                <h3 class="card-title">Terrain de jeu</h3>

                <div class="card-btn">

                  <ion-icon name="arrow-forward-outline"></ion-icon>
                </div>

              </a>
            </li>

          </ul>
        </div>
      </section>

      <!-- blogs -->

      <section class="blog" id="blog">

        <div class="container">

          <p class="section-subtitle">Actualités et Blogs</p>

          <h2 class="h2 section-title">Derniers flux d'actualités</h2>

          <ul class="blog-title has-scrollbar">

            <li>
              <div class="blog-card">

                <figure class="card-banner">
                  <img src="assets/images/blog-1.png" alt="Le design d’intérieur le plus inspirant de 2024"
                    class="w-100">
                </figure>

                <div class="blog-content">

                  <div class="blog-content-top">

                    <ul class="card-meta-list">
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="person"></ion-icon>
                          <span>Par: Admin</span>
                        </a>
                      </li>
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="pricetags"></ion-icon>
                          <span>Intérieure</span>
                        </a>
                      </li>
                    </ul>

                    <h3 class="h3 blog-title upp">
                      <a href="#">Le design d’intérieur le plus inspirant de 2024</a>
                    </h3>


                  </div>

                  <div class="blog-content-bottom">

                    <div class="publish-date">
                      <ion-icon name="calendar"></ion-icon>

                      <time datetime="08-06-2024" class="datetime">08 Juin 2024</time>

                    </div>

                    <a href="#" class="read-more-btn">En savoir plus</a>
                  </div>
                </div>
              </div>
            </li>

            <li>
              <div class="blog-card">

                <figure class="card-banner">
                  <img src="assets/images/blog-2.jpg" alt="Batiment récemment construit" class="w-100">
                </figure>

                <div class="blog-content">

                  <div class="blog-content-top">

                    <ul class="card-meta-list">
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="person"></ion-icon>
                          <span>Par: Admin</span>
                        </a>
                      </li>
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="pricetags"></ion-icon>
                          <span>Vue d'extérieur</span>
                        </a>
                      </li>
                    </ul>

                    <h3 class="h3 blog-title upp">
                      <a href="#">Batiment récemment construit</a>
                    </h3>


                  </div>

                  <div class="blog-content-bottom">

                    <div class="publish-date">
                      <ion-icon name="calendar"></ion-icon>

                      <time datetime="08-06-2024" class="datetime">08 Juin 2024</time>

                    </div>

                    <a href="#" class="read-more-btn">En savoir plus</a>
                  </div>
                </div>
              </div>
            </li>

            <li>
              <div class="blog-card">

                <figure class="card-banner">
                  <img src="assets/images/blog-3.jpg" alt="Rénover un salon ? Les experts partagent leurs secrets"
                    class="w-100">
                </figure>

                <div class="blog-content">

                  <div class="blog-content-top">

                    <ul class="card-meta-list">
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="person"></ion-icon>
                          <span>Par: Admin</span>
                        </a>
                      </li>
                      <li>
                        <a href="#" class="card-meta-link">
                          <ion-icon name="pricetags"></ion-icon>
                          <span>Chambre </span>
                        </a>
                      </li>
                    </ul>

                    <h3 class="h3 blog-title upp">
                      <a href="#">Rénover un salon ? Les experts partagent leurs secrets</a>
                    </h3>


                  </div>

                  <div class="blog-content-bottom">

                    <div class="publish-date">
                      <ion-icon name="calendar"></ion-icon>

                      <time datetime="08-06-2024" class="datetime">08 Juin 2024</time>

                    </div>

                    <a href="#" class="read-more-btn">En savoir plus</a>
                  </div>
                </div>
              </div>
            </li>

          </ul>
        </div>
      </section>

      <!-- la partie cta -->

      <section class="cta">
        <div class="container">

          <div class="cta-card">
            <div class="card-content">
              <h2 class="h2 card-title">A la recherche d'une chambre ou maison pour rester étudier?</h2>

              <p class="card-text">Pas besoin d'aller loin chercher une chambre ou maison pour tes études à
                l'Université Ndéré</p>
              <p class="card-text">Car elle a tous dans son sain</p>
            </div>

            <button class="btn cta-btn">
              <span>Explorer les propriétés</span>

              <ion-icon name="arrow-forward-outline"></ion-icon>
            </button>
          </div>
        </div>
      </section>





    </article>
  </main>

 <!-- NAV BAR POUR LE PANIER DE L'USER 
 <div class="mobile mobile-cart cart mobile-right none">
  <div class="overlay"></div>
  <div class="mobile-content fixed">
    <div class="mobile-content-header relative">
      <div class="mobile-title">
        <i class="bi bi-cart"></i>
        <h2>Shopping Cart</h2>
      </div>
      <div class="mobile-close absolute" data-mobile="mobile-cart">
        <img src="assets/images/icons/close.png" alt="" data-mobile="mobile-cart">
      </div>
    </div>
    <div class="mobile-content-body py-10 px-10">
      <ul class="cart-product-items flex gap-25">
        <li class="cart-product-item flex">
          <div class="product-deatils flex-1 flex column aic jcc">
            <div class="product-name">Pantalon Supreme pour femme d'affaires</div>
            <div class="product-reviews py-5">
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star"></i> (586)
            </div>
            <div class="product-quantity-and-price">2 x 99.99£</div>
          </div>
          <div class="product-image relative">
            <img src="assets/images/product/featured/1.webp" alt="">
            <div class="remove-product absolute">
              <img src="assets/images/icons/close.png" alt="">
            </div>
          </div>
        </li>
        <li class="cart-product-item flex">
          <div class="product-deatils flex-1 flex column aic jcc">
            <div class="product-name">Pantalon Supreme pour femme d'affaires</div>
            <div class="product-reviews py-5">
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star"></i> (586)
            </div>
            <div class="product-quantity-and-price">2 x 99.99£</div>
          </div>
          <div class="product-image relative">
            <img src="assets/images/product/featured/2.webp" alt="">
            <div class="remove-product absolute">
              <img src="assets/images/icons/close.png" alt="">
            </div>
          </div>
        </li>
        <li class="cart-product-item flex">
          <div class="product-deatils flex-1 flex column aic jcc">
            <div class="product-name">Pantalon Supreme pour femme d'affaires</div>
            <div class="product-reviews py-5">
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star"></i> (586)
            </div>
            <div class="product-quantity-and-price">2 x 99.99£</div>
          </div>
          <div class="product-image relative">
            <img src="assets/images/product/featured/3.webp" alt="">
            <div class="remove-product absolute">
              <img src="assets/images/icons/close.png" alt="">
            </div>
          </div>
        </li>
        <li class="cart-product-item flex">
          <div class="product-deatils flex-1 flex column aic jcc">
            <div class="product-name">Pantalon Supreme pour femme d'affaires</div>
            <div class="product-reviews py-5">
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star selected"></i>
              <i class="fa-solid fa-star"></i> (586)
            </div>
            <div class="product-quantity-and-price">2 x 99.99£</div>
          </div>
          <div class="product-image relative">
            <img src="assets/images/product/featured/4.webp" alt="">
            <div class="remove-product absolute">
              <img src="assets/images/icons/close.png" alt="">
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div class="mobile-content-footer">
      <button class="view-cart btn">View Cart</button>
      <button class="Checkout btn">Checkout</button>
    </div>
  </div>
</div>
-->
  <!-- footer -->

  <footer class="footer">
    <div class="footer-top">
      <div class="container">
        <div class="footer-brand">
          <a href="#" class="logo">
            <img src="assets/images/logo-light.png" alt="Homeverse logo">
          </a>

          <p class="section-text">
            Lorem Ipsum is simply dummy text of the and typesetting industry.
            Lorem Ipsum is dummy text of the printing.
          </p>

          <ul class="contact-list">
            <li>
              <a href="#" class="contact-link">
                <ion-icon name="location-outline"></ion-icon>

                <address>Ngaoundéré(Dang-Bini)</address>
              </a>
            </li>

            <li>
              <a href="tel:+237656000010" class="contact-link">
                <ion-icon name="call-outline"></ion-icon>

                <span>+237 656 100 010</span>
              </a>
            </li>

            <li>
              <a href="mailto:kagbemathias3@gmail.com" class="contact-link">
                <ion-icon name="mail-outline"></ion-icon>

                <span>univ-ndere444@gmail.com</span>
              </a>
            </li>

          </ul>

          <ul class="social-list">
            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>
        </div>

        <div class="footer-link-box">
          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Université-Ngaoundéré</p>
            </li>

            <li>
              <a href="#" class="footer-link">À propos</a>
            </li>

            <li>
              <a href="#" class="footer-link">Blog</a>
            </li>

            <li>
              <a href="#" class="footer-link">Voir tout</a>
            </li>

            <li>
              <a href="#" class="footer-link">Location Maps</a>
            </li>

            <li>
              <a href="#" class="footer-link">FAQ</a>
            </li>

            <li>
              <a href="#" class="footer-link">Contactez-nous</a>
            </li>


          </ul>

          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Services</p>
            </li>

            <li>
              <a href="#" class="footer-link">Suivi de commande</a>
            </li>

            <li>
              <a href="#" class="footer-link">Liste de souhaits</a>
            </li>

            <li>
              <a href="#" class="footer-link">Se connecter</a>
            </li>

            <li>
              <a href="#" class="footer-link">Mon compte</a>
            </li>

            <li>
              <a href="#" class="footer-link">termes & conditions</a>
            </li>

            <li>
              <a href="#" class="footer-link">Offres promotionnelles</a>
            </li>


          </ul>

          <ul class="footer-list">
            <li>
              <p class="footer-list-title">Service client</p>
            </li>

            <li>
              <a href="#" class="footer-link">Se connecter</a>
            </li>

            <li>
              <a href="#" class="footer-link">Mon compte</a>
            </li>

            <li>
              <a href="#" class="footer-link">Liste de souhaits</a>
            </li>

            <li>
              <a href="#" class="footer-link">Suivi de commande</a>
            </li>

            <li>
              <a href="#" class="footer-link">FAQ</a>
            </li>

            <li>
              <a href="#" class="footer-link">Contactez-nous</a>
            </li>


          </ul>


        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; 2024 <a href="#">Groupe:15</a>. Tous droits réservés

        </p>

      </div>
    </div>

  </footer>


  <script src="assets/javaScript/Script.js"></script>

  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

  <script src="assets/javaScript/main.js"></script>
  <script src="https://unpkg.com/typed.js@2.0.16/dist/typed.umd.js"></script>
  <script>
    // Types JS
    var typingEffect = new Typed(".multiText", {
      strings: ["Confortable", "contemporaine", "traditionnelle", "moderne", "provençale", "de plain-pied", "à étage", "en bois"],
      loop: true,
      typeSpeed: 100,
      backSpeed: 80,
      backDelay: 2000
    })
    // End of typed JS
  </script>

</body>

</html>